<template>
  <div>
    <h1>El meu gos té un blog</h1>
    <p>Fes clic a la pilota</p>
    <div>
      <img ref="ball" src="/assets/pilota.png" alt="pilota" class="pilota" @click="togglePause" />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      animationId: null,
      x: 50,
      y: 50,
      vx: 220, // pixels per second
      vy: 180,
      paused: false,
    };
  },
  mounted() {
    const el = this.$refs.ball;
    if (!el) return;

    // ensure the element is positioned for animation
    el.style.position = 'fixed';
    el.style.left = this.x + 'px';
    el.style.top = this.y + 'px';
    el.style.zIndex = 9999;

    let lastTime = null;
    const loop = (timestamp) => {
      if (!lastTime) lastTime = timestamp;
      const dt = (timestamp - lastTime) / 1000; // seconds
      lastTime = timestamp;

      if (!this.paused) {
        const rect = el.getBoundingClientRect();
        const w = window.innerWidth;
        const h = window.innerHeight;

        this.x += this.vx * dt;
        this.y += this.vy * dt;

        // bounce off left/right
        if (this.x <= 0) {
          this.x = 0;
          this.vx = Math.abs(this.vx);
        } else if (this.x + rect.width >= w) {
          this.x = w - rect.width;
          this.vx = -Math.abs(this.vx);
        }

        // bounce off top/bottom (avoid overlaying system UI by using innerHeight)
        if (this.y <= 0) {
          this.y = 0;
          this.vy = Math.abs(this.vy);
        } else if (this.y + rect.height >= h) {
          this.y = h - rect.height;
          this.vy = -Math.abs(this.vy);
        }

        el.style.left = Math.round(this.x) + 'px';
        el.style.top = Math.round(this.y) + 'px';
      }

      this.animationId = requestAnimationFrame(loop);
    };

    this.animationId = requestAnimationFrame(loop);
  },
  beforeUnmount() {
    if (this.animationId) cancelAnimationFrame(this.animationId);
  },
  methods: {
    togglePause() {
      // Navigate to the posts page when the ball is clicked
      if (this.$router) {
        this.$router.push('/llista');
      } else if (window.location) {
        window.location.href = '/llista';
      }
    }
  }
};
</script>

<style>
.pilota {
  width: 200px; /* smaller size */
  height: auto;
  display: inline-block;
  cursor: pointer;
  transition: transform 0.12s ease;
}
.pilota:hover {
  transform: scale(1.05);
}
</style>
