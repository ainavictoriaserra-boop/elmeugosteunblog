<template>
  <div class="home-page">
    <h1>Per a tu</h1>

    <!-- Mensaje si hay error o está cargando -->
    <div v-if="error" class="alert alert-danger" role="alert">
      {{ error }}
    </div>

    <!-- Lista de publicaciones -->
    <div class="row g-4" v-if="publicacions.length > 0">
      <div
        class="col-12 col-sm-6 col-lg-6"
        v-for="p in publicacions"
        :key="p.id"
      >
          <Publicacio
            :id="p.id"
            :texto="p.texto"
            :textfoto="p.textfoto"
            :img="p.img"
            :data="p.data"
            :like="p.like"
          />
      </div>
    </div>

    <!-- Mensaje si no hay publicaciones -->
    <div v-else class="alert alert-info" role="alert">
      Encara no hi ha publicacions...
    </div>
  </div>
</template>

<script>
import Publicacio from '../components/Publicacio.vue'

export default {
  components: {
    Publicacio
  },
  data() {
    return {
      publicacions: [],
        listapublicacions: '/elmeugosteunblog/publis.json',
      error: null
    }
  },
  mounted() {
    fetch(this.listapublicacions)
      .then(res => {
        if (!res.ok) {
          throw new Error('No s\'ha pogut carregar el fitxer publis.json')
        }
        return res.json()
      })
      .then(data => {
        this.publicacions = data
      })
      .catch(err => {
        this.error = err.message
        console.error('Error carregant les publicacions:', err)
      })
  }
}
</script>

<style>
.home-page {
  padding: 2rem;
  text-align: center;
}

h1 {
  color: #333;
  margin-bottom: 2rem;
}
</style>
