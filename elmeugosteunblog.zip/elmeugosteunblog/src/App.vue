<template>
  <div class="layout">
    
    <!-- MENÚ IZQUIERDA -->
    <nav class="side-menu">
      <router-link to="/">Inici</router-link>
      <router-link to="/llista">Posts</router-link>
      <router-link to="/reflexio">Reflexió</router-link>
    </nav>

    <!-- CONTENIDO CENTRAL -->
    <main class="content">
      <router-view />
    </main>

    <!-- FOOTER DERECHA -->
    <aside class="right-footer">
      <div>Fet per Aina0. i AinaV.</div>
    </aside>

  </div>
</template>

<style>
/* GRID DE 3 COLUMNAS: IZQUIERDA / CENTRO / DERECHA */
.layout {
  display: grid;
  grid-template-columns: 180px 1fr 60px; /* reducir ancho del footer derecho */
  height: 100vh;
}

/* MENÚ IZQUIERDO */
.side-menu {
  background: #bd9a56;
  display: flex;
  flex-direction: column;
  justify-content: center;  /* centra els links verticalment */
  align-items: center;      /* centra horitzontalment */
  padding: 1rem;
  gap: 2rem;               
  height: 100%;
}

.side-menu a {
  color: white;
  text-decoration: none;
  font-size: 1.2rem;
}

.side-menu a.router-link-exact-active {
  font-weight: bold;
  text-decoration: underline;
}

/* CONTENIDO CENTRAL */
.content {
  padding: 10px;
  overflow-y: auto;
}

/* FOOTER DERECHO */
.right-footer {
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 40px;      
  text-align: center;
  padding: 0.75rem;
  height: 100%;
}

.right-footer div {
  writing-mode: vertical-rl; /* text en vertical */
  text-orientation: mixed;   /* evita que les lletres rotin individualment */
  font-size: 0.95rem;
}

</style>
