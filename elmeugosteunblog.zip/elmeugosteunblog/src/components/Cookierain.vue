<template>
  <div class="cookie-rain-container">
    <div
      v-for="(cookie, index) in cookies"
      :key="index"
      class="cookie-fall"
      :style="{ left: cookie.left + '%', animationDelay: cookie.delay + 's', animationDuration: cookie.duration + 's', backgroundImage: 'url(' + cookie.src + ')' }"
      @click="removeCookie(index)"
    >
      <img
        :src="cookie.src"
        :alt="cookie.alt"
        class="cookie-img"
      />
    </div>
  </div>
</template>

<script>
export default {
  props: {
    // nombre de galetes a generar (intensitat)
    count: {
      type: Number,
      default: 40
    }
  },
  data() {
    return {
      cookies: []
    };
  },
  mounted() {
    // Generar galetes segons el prop `count` amb posicions, delays i duracions aleatòries
    const images = ['/elmeugosteunblog/assets/galleta1.png', '/elmeugosteunblog/assets/galleta2.png'];
    let maxDuration = 0;
    const total = Math.max(0, Math.floor(this.count));
      for (let i = 0; i < total; i++) {
      const duration = 3 + Math.random() * 2; // 3s -> 5s
      maxDuration = Math.max(maxDuration, duration);
        this.cookies.push({
          src: images[i % images.length],
          alt: `galleta${(i % images.length) + 1}`,
          // spawn horizontally across and start above the viewport
          left: Math.random() * 120 - 10, // -10% .. 110%
          delay: Math.random() * 1, // up to 1s stagger
          duration: duration
        });
    }

    // Auto-destruir después de la duración máxima + 1s de margen
    setTimeout(() => {
      this.$emit('done');
    }, Math.ceil(maxDuration * 1000) + 1000);
  },
  methods: {
    removeCookie(index) {
      this.cookies.splice(index, 1);
      const audio = new Audio('/elmeugosteunblog/assets/mossegada.mp3');
      audio.play();
    }
  }
};
</script>

<style>
.cookie-rain-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  pointer-events: none;
  z-index: 9999;
  overflow: hidden;
}

.cookie-fall {
  position: fixed;
  width: 100px;
  height: 100px;
  top: -120px;
  animation: fall-down 5s linear forwards;
  background-size: 90%;
  background-repeat: no-repeat;
  background-position: center;
  pointer-events: auto;
}

.cookie-img {
  display: none;
}

@keyframes fall-down {
  0% {
    transform: translateY(0) rotate(0deg) scale(1);
    opacity: 1;
  }
  50% {
    opacity: 1;
  }
  100% {
    transform: translateY(120vh) rotate(360deg) scale(0.8);
    opacity: 0;
  }
}
</style>
