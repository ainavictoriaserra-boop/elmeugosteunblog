<template>
  <div class="posts-container" ref="container">
    <CookieRain v-if="showCookieRain" :count="likeBurstCount" @done="showCookieRain = false" />
    <img 
      :src="imageSrc" 
      :alt="texto" 
      class="post-image" 
      :class="{ 'image-loaded': imageLoaded }"
      @click="openOverlay"
      @mouseenter="onImageEnter" 
      @mouseleave="onImageLeave" 
      @touchstart.prevent="onImageEnter" 
      @touchend.prevent="onImageLeave" 
    />
    <div class="post-content">
      <p class="post-text">{{ texto }}</p>
      <p class="post-date">{{ formatDate(data) }}</p>
      <div class="post-likes">
        <button class="like-button" :class="{ liked: liked }" @click="toggleLike" :aria-pressed="liked" :aria-label="liked ? 'No me gusta' : 'Me gusta'">
          <i class="fa-solid fa-bone" aria-hidden="true"></i>
        </button>
        <span class="likes-count">{{ likesCount }}</span>
      </div>
      <div v-if="link" class="post-link">
        <router-link v-if="isInternal" :to="link">{{ linkTextComputed }}</router-link>
        <a v-else :href="link" target="_blank" rel="noopener noreferrer">{{ linkTextComputed }}</a>
      </div>
    </div>

    <!-- Overlay per mostrar el quadre de text gran -->
    <div v-if="showOverlay" class="image-overlay" @click.self="closeOverlay">
      <div class="overlay-content" role="dialog" aria-modal="true">
        <button class="overlay-close" @click="closeOverlay" aria-label="Tancar">✕</button>

        <!-- Títol a dalt en negreta -->
        <header class="overlay-header">
          <h2 class="overlay-title">{{ texto }}</h2>
        </header>

        <!-- Cos: imatge a l'esquerra, text a la dreta -->
        <section class="overlay-body">
          <div class="overlay-image">
            <img :src="imageSrc" :alt="texto" />
          </div>
          <div class="overlay-right">
            <div class="overlay-fulltext">
              <p>{{ textfoto || texto }}</p>
            </div>
          </div>
        </section>

        <!-- Peu: data a l'esquerra -->
        <footer class="overlay-footer">
          <span class="overlay-date">{{ formatDate(data) }}</span>
        </footer>
      </div>
    </div>
  </div>
</template>

<script>
import CookieRain from './CookieRain.vue';

export default {
  components: { CookieRain },
  props: ["id", "img", "texto", "textfoto", "data", "like"],
  computed: {
    imageSrc() {
      if (!this.img) return '';
      const value = String(this.img).trim();
      if (
        /^https?:/.test(value) || 
        /^data:/.test(value) || 
        value.startsWith('/')
      ) {
        return value;
      }
      try {
        return new URL(`../assets/${value}`, import.meta.url).href;
      } catch (err) {
        return `/assets/${value}`;
      }
    },
    isInternal() {
      if (!this.link) return false;
      return String(this.link).startsWith('/');
    },
    linkTextComputed() {
      return this.linkText || 'Veure';
    }
  },
  data() {
    return {
      liked: false,
      likesCount: Number(this.like) || 0,
      showCookieRain: false,
      // nombre de galetes per defecte (una "pau"), s'usarà multiplicat si cal
      likeBurstCount: 40,
      imageLoaded: false,
      observer: null,
      showOverlay: false
    };
  },
  mounted() {
    // Intersection Observer para detectar cuando el post entra en pantalla
    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.imageLoaded = true;
          this.observer.unobserve(this.$refs.container);
        }
      });
    }, {
      threshold: 0.1 // Se activa cuando el 10% del elemento es visible
    });
    
    if (this.$refs.container) {
      this.observer.observe(this.$refs.container);
    }
  },
  beforeUnmount() {
    if (this.observer) {
      this.observer.disconnect();
    }
    this.removeOverlayEffects();
  },
  methods: {
    formatDate(dateString) {
      if (!dateString) return '';
      return new Date(dateString).toLocaleDateString('ca-ES');
    },
    toggleLike() {
      this.liked = !this.liked;
      if (this.liked) {
        this.likesCount += 1;
          // simular 3 likes a la vegada: generar 3x galetes
          this.likeBurstCount = 40 * 3;
          this.showCookieRain = true;
      } else {
        this.likesCount = Math.max(0, this.likesCount - 1);
      }
      this.$emit('like-changed', { id: this.id, likes: this.likesCount, liked: this.liked });
    },
    onImageEnter() {
      if (this.$el && this.$el.classList) this.$el.classList.add('image-hover');
    },
    onImageLeave() {
      if (this.$el && this.$el.classList) this.$el.classList.remove('image-hover');
    },

    // Overlay handlers
    openOverlay() {
      this.showOverlay = true;
      // Bloquejar scroll del body
      document.body.style.overflow = 'hidden';
      // Afegir listener per tecla Esc
      window.addEventListener('keydown', this.onKeyDown);
      // Reproducir sonido al tocar el post
      const audio = new Audio('/elmeugosteunblog/assets/ladrido.mp3');
      audio.play();
    },
    closeOverlay() {
      this.showOverlay = false;
      this.removeOverlayEffects();
    },
    removeOverlayEffects() {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', this.onKeyDown);
    },
    onKeyDown(e) {
      if (e.key === 'Escape' || e.key === 'Esc') {
        this.closeOverlay();
      }
    }
  }
};
</script>

<style>
.posts-container {
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 420px;
  margin: 0.75rem auto;
  border: 1px solid #edd8adff;
  background-color: #edd8adff;
  padding: 0.6rem;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.04);
}

.post-image {
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 4px;
  opacity: 0;
  animation: fadeInUp 0.6s ease-out forwards;
  cursor: pointer;
}

.post-image:not(.image-loaded) {
  opacity: 0;
  animation: none;
}

.post-image.image-loaded {
  animation: fadeInUp 0.6s ease-out forwards;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.post-content {
  margin-top: 0.5rem;
  text-align: left;
}

.post-text {
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.post-date, .post-likes {
  font-size: 0.9rem;
  color: #666;
  margin: 0;
}

.post-text, .post-date {
  text-align: left;
}

.post-link {
  margin-top: 0.5rem;
}

.post-link a, .post-link a.router-link-active, .post-link a.router-link-exact-active, .post-link router-link {
  color: #007BFF;
  text-decoration: none;
}

.post-link a:hover, .post-link router-link:hover {
  text-decoration: underline;
}

.post-likes {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 0.5rem;
  margin: 0;
}

.like-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  padding: 0;
  border: none;
  background: transparent;
  cursor: pointer;
}

.like-button .fa-solid {
  color: #666;
  font-size: 22px;
  transition: color 0.12s ease-in-out, transform 0.12s ease;
}

.like-button:active .fa-solid {
  transform: scale(0.95);
}

.like-button.liked .fa-solid {
  color: #5b8de9ff;
}

.likes-count {
  font-size: 1.1rem;
  font-weight: 600;
  color: #333;
}

.like-button:hover .fa-solid {
  transform: scale(1.06);
}

.posts-container.image-hover {
  animation: shake 0.25s ease-in-out infinite;
}

@keyframes shake {
  0% { transform: translateX(0); }
  20% { transform: translateX(-2px); }
  40% { transform: translateX(2px); }
  60% { transform: translateX(-2px); }
  80% { transform: translateX(2px); }
  100% { transform: translateX(0); }
}

/* Overlay styles */
.image-overlay {
  position: fixed;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(12, 12, 12, 0.55);
  z-index: 1000;
  padding: 2vh 2vw;
}

.overlay-content {
  position: relative;
  width: min(1100px, 92vw);
  height: min(800px, 86vh);
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.3);
  padding: 1rem;
  overflow: auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

/* Header (titol) */
.overlay-header {
  border-bottom: 1px solid #eee;
  padding-bottom: 0.5rem;
}
.overlay-title {
  margin: 0;
  font-size: 1.25rem;
  font-weight: 800;
  color: #222;
}

/* Body: image left, text right */
.overlay-body {
  display: flex;
  gap: 1rem;
  flex: 1 1 auto;
  align-items: stretch;
}

.overlay-image {
  flex: 0 0 45%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #d6fcffff;
  border-radius: 6px;
  padding: 6px;
}
.overlay-image img {
  width: 100%;
  height: auto;
  max-height: 100%;
  object-fit: contain;
  border-radius: 4px;
}

.overlay-right {
  flex: 1 1 55%;
  overflow: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.overlay-fulltext {
  padding: 0.5rem;
}
.overlay-fulltext p {
  margin: 0;
  font-size: 1rem;
  color: #333;
  line-height: 1.5;
  white-space: pre-wrap;
  text-align: left;
}

/* Footer: data a l'esquerra */
.overlay-footer {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding-top: 0.5rem;
  border-top: 1px solid #eee;
}
.overlay-date {
  font-size: 0.9rem;
  color: #666;
}

/* Close button */
.overlay-close {
  position: absolute;
  top: 12px;
  right: 12px;
  border: none;
  background: transparent;
  font-size: 1.25rem;
  cursor: pointer;
  padding: 6px;
  line-height: 1;
}

/* Responsive adjustments */
@media (max-width: 900px) {
  .overlay-body {
    flex-direction: column;
  }
  .overlay-image {
    flex-basis: auto;
    width: 100%;
    max-height: 40vh;
  }
  .overlay-right {
    width: 100%;
  }
  .overlay-title {
    font-size: 1.1rem;
  }
}
</style>