import { createRouter, createWebHistory } from 'vue-router'
import Home from '../pages/Home.vue'
import Reflexio from '../pages/Reflexio.vue'
import Llistapublis from '../pages/Llistapublis.vue'

const routes = [
 { path: '/', name: 'home', component: Home },
 { path: '/reflexio', name: 'reflexio', component: Reflexio },
 { path: '/llista', name: 'llista', component: Llistapublis }
]


const router = createRouter({
 history: createWebHistory(import.meta.env.BASE_URL),
 routes
})


export default router
