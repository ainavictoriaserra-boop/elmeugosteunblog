<template>
  <div>
    <h1>El Nostre Projecte de Net Art Caní</h1>
    <div style="display: flex; align-items: flex-start;">
      <div>
        <p>Benvinguts a “El meu gos té un blog, una experiència de Net Art creada amb Vue que transforma la percepció del món caní en una peça web immersiva i juganera. </p>
        <p>Aquesta obra neix de la idea de mirar internet amb ulls de gos: colors limitats, impulsos constants, caos tendre, humor i un flux mental ple d’estímuls. El resultat és un espai que ja no funciona com una web convencional, sinó com un blog/social network creat i viscut per un gos.</p>
        <p>Aquí l’usuari no només navega: juga, reactiva sons, persegueix objectes, desencadena pensaments i explora memòries. Des del primer clic a una pilota rebotant fins a la pluja de xuxes quan dones like, tot respon a emocions del gos representades amb animacions, vibracions, capes visuals i una lògica pròpia.</p>
        <p>La peça combina narrativa, estètica i percepció emocional: l’univers seriós de la protectora de la nostra Pràctica 1 es transforma ara en un relat íntim i juganer, explicat des del punt de vista del seu protagonista. Les fotos i anècdotes apareixen amb scroll, i els posts reaccionen a cada estímul amb colors i vibracions.</p>
        <p>Amb una estètica minimalista, lleugerament caòtica i pròxima al Net Art contemporani, la web convida a explorar un ecosistema digital que no busca ser racional, sinó sensorial: una mente canina feta interfície. L’experiència està pensada per a persones curioses, amants dels gossos i del joc, i per a qui busca formats digitals que trenquen la lògica habitual d’una web.</p>
        <p>Entra, clica, escolta, persegueix i deixa’t portar pel caos tendre d’un gos que, per fi, té el seu propi blog.</p>
      </div>
      <img src="/assets/mood.png" alt="Imatge de reflexió" style="width: 400px; margin-left: 20px;" />
    </div>
  </div>
</template>